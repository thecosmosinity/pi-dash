/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// A utility to provide Pi digits for verification
// Including the leading '3' for better user experience
export const PI_DIGITS = "31415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679" +
  "8214808651328230664709384460955058223172535940812848111745028410270193852110555964462294895493038196";

export function verifyPiDigit(input: string, index: number): boolean {
  if (index >= PI_DIGITS.length) return false;
  return input === PI_DIGITS[index];
}
