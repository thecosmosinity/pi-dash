/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AlertTriangle, CheckCircle2, Cpu, Activity, Hash } from 'lucide-react';
import { PI_DIGITS } from './services/piService';

const INITIAL_GOAL = 10; 
const DIGITS_PER_POINT = 5;

export default function App() {
  const [typedDigits, setTypedDigits] = useState<string>('');
  const [counter, setCounter] = useState(INITIAL_GOAL);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isError, setIsError] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
    const lastChar = value.slice(-1);
    
    if (!lastChar) return;

    const currentIndex = typedDigits.length;
    const expectedChar = PI_DIGITS[currentIndex];

    if (lastChar === expectedChar) {
      const newTyped = typedDigits + lastChar;
      setTypedDigits(newTyped);
      setIsError(false);

      if (newTyped.length % DIGITS_PER_POINT === 0) {
        setCounter(prev => Math.max(0, prev - 1));
      }
    } else {
      setIsError(true);
      setTimeout(() => setIsError(false), 300);
    }
    e.target.value = '';
  };

  useEffect(() => {
    if (counter === 0) setIsGameOver(true);
  }, [counter]);

  const resetGame = () => {
    setCounter(INITIAL_GOAL);
    setTypedDigits('');
    setIsGameOver(false);
    setIsError(false);
  };

  const progress = ((INITIAL_GOAL - counter) / INITIAL_GOAL) * 100;

  return (
    <div className="min-h-screen bg-[#070708] text-white font-mono flex flex-col items-center justify-center p-4 md:p-12 overflow-hidden selection:bg-orange-500/30">
      {/* Visual background layers */}
      <div className="fixed inset-0 pointer-events-none opacity-5 flex flex-col justify-end p-20 gap-4">
        <div className="text-[200px] font-black leading-none select-none italic tracking-tighter">PI.CORE</div>
        <div className="text-[120px] font-black leading-none select-none text-orange-500 tracking-tighter uppercase">Calculation_Active</div>
      </div>

      <div className="relative w-full max-w-2xl">
        <AnimatePresence mode="wait">
          {!isGameOver ? (
            <motion.div
              key="active-box"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 1.1, opacity: 0 }}
              className="bg-[#121316] border-2 border-white/10 rounded-[2.5rem] shadow-[0_45px_100px_-20px_rgba(0,0,0,0.8)] overflow-hidden relative"
            >
              {/* Internal Scanline Effect */}
              <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%] opacity-20" />

              {/* Box Header */}
              <div className="p-8 border-b border-white/5 flex justify-between items-end bg-[#18191C]/50 relative z-10">
                <div className="flex flex-col gap-1">
                  <span className="text-[9px] uppercase tracking-[0.4em] font-black text-orange-500 flex items-center gap-2">
                    <Activity className="w-3 h-3" /> PI_STREAMER.EXE
                  </span>
                  <div className="text-xl font-black uppercase italic tracking-tighter">Computation_Node</div>
                </div>
                <div className="text-right">
                   <div className="text-[9px] uppercase tracking-widest text-white/20 mb-1">Status</div>
                   <div className="text-2xl font-light tabular-nums text-orange-200 tracking-tighter">WAITING_FOR_INPUT</div>
                </div>
              </div>

              {/* Workspace */}
              <div className="p-12 md:p-16 text-center flex flex-col items-center relative z-10">
                <div className="mb-12 relative group">
                  <div className="text-[120px] md:text-[180px] font-black leading-none tracking-tighter tabular-nums flex items-center justify-center gap-2 select-none group-hover:scale-105 transition-transform duration-500">
                    <span className="text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.1)]">{counter}</span>
                    <span className="text-white/5 text-[60px] md:text-[100px]">/</span>
                    <span className="text-white/5 text-[60px] md:text-[100px]">{INITIAL_GOAL}</span>
                  </div>
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-orange-500/5 blur-[80px] rounded-full pointer-events-none opacity-50" />
                </div>

                {/* Digit Display Window */}
                <div className="w-full max-w-md bg-black/40 p-6 rounded-2xl border border-white/5 mb-8 overflow-hidden relative min-h-[120px]">
                   <div className="text-left text-[10px] uppercase tracking-[.3em] font-black text-white/20 mb-4 border-b border-white/5 pb-2 flex justify-between">
                      <span>Stream Output</span>
                      <span className="text-orange-500/40">{typedDigits.length} Digits Validated</span>
                   </div>
                   <div className="flex flex-wrap gap-x-1 gap-y-2 justify-start font-black text-4xl leading-tight">
                      {typedDigits.split('').map((d, i) => (
                        <motion.span 
                          initial={{ opacity: 0, scale: 1.5 }}
                          animate={{ opacity: 1, scale: 1 }}
                          key={i} 
                          className="text-orange-500"
                        >
                          {d}{i === 0 ? "." : ""}
                        </motion.span>
                      ))}
                      <motion.span animate={{ opacity: [1, 0, 1] }} transition={{ repeat: Infinity, duration: 0.8 }} className="text-white/20">_</motion.span>
                   </div>
                </div>

                <div className={`w-full max-w-sm relative p-8 bg-black/50 rounded-3xl border-2 transition-all duration-500 ${isError ? 'border-red-500 scale-[0.98] blur-[1px]' : 'border-white/10 ring-1 ring-white/5'}`}>
                   <input
                    ref={inputRef}
                    type="text"
                    className="w-full bg-transparent border-none text-center text-4xl font-black outline-none placeholder:text-white/5 select-none caret-orange-500"
                    placeholder="NEXT_DIGIT"
                    onChange={handleInput}
                    autoFocus
                  />
                  <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-[#121316] border border-white/10 px-4 py-1 rounded-full text-[8px] uppercase tracking-[0.4em] font-black text-white/40">
                    Real-time Verification Active
                  </div>
                </div>

                <div className="mt-12 w-full max-w-xs space-y-4">
                   <div className="flex justify-between text-[8px] uppercase tracking-widest font-black text-white/20">
                      <span>Rate: 5 Digits per point</span>
                   </div>
                   <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        className="h-full bg-orange-500 shadow-[0_0_15px_rgba(249,115,22,0.6)]"
                      />
                   </div>
                </div>
              </div>

              {/* Status footer */}
              <div className="px-8 py-4 opacity-10 flex justify-center gap-12 text-[7px] uppercase tracking-[0.5em] font-black border-t border-white/5 relative z-10">
                <div className="flex items-center gap-2"><Cpu className="w-2 h-2" /> CORE_LOAD: LOW</div>
                <div>SEQUENCE_HASH: {Math.random().toString(16).slice(2, 8).toUpperCase()}</div>
                <div>BUFFER_SIZE: {typedDigits.length}D</div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              layout
              key="gameover-box"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-[#121316] border-2 border-white/10 rounded-[2.5rem] p-24 text-center shadow-[0_50px_100px_-20px_rgba(249,115,22,0.15)] relative overflow-hidden"
            >
               <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%] opacity-20" />

              <div className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-10 border-2 relative z-10 bg-green-500/10 border-green-500/30">
                <CheckCircle2 className="w-10 h-10 text-green-500" />
              </div>
              
              <h2 className="text-6xl font-black mb-4 tracking-tighter uppercase italic relative z-10 text-white">
                CORE_SYNCED
              </h2>
              
              <p className="text-white/20 uppercase tracking-[0.3em] text-[9px] max-w-sm mx-auto mb-16 leading-relaxed relative z-10">
                Sequence archived. Data points collected. System stabilized.
              </p>

              <button 
                onClick={resetGame}
                className="relative z-10 px-12 py-5 bg-orange-500 text-white font-black rounded-2xl hover:bg-orange-600 transition-all uppercase tracking-[0.4em] text-[10px] shadow-[0_10px_30px_-5px_rgba(249,115,22,0.4)]"
              >
                Reset Computation
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="mt-12 text-[8px] uppercase tracking-[0.8em] font-black text-white/5 select-none text-center">
        PI_TERMINAL_V2.5 // AI_STUDIO_PROTOCOL
      </div>
    </div>
  );
}
